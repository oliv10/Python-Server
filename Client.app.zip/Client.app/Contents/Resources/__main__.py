import Client

if __name__ == '__main__':
    Client.client().cmdloop()